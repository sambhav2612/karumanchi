from main import BloomFilter
name = "bloomf"
